//
//  examenIOSApp.swift
//  examenIOS
//
//  Created by Admin on 11/3/25.
//

import SwiftUI

@main
struct examenIOSApp: App {
    var body: some Scene {
        WindowGroup {
            MainView();
        }
    }
}
