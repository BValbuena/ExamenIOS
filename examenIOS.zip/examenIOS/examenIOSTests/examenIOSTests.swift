//
//  examenIOSTests.swift
//  examenIOSTests
//
//  Created by Admin on 11/3/25.
//

import Testing
@testable import examenIOS

struct examenIOSTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
